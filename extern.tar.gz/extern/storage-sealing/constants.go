package sealing

// Epochs
const InteractivePoRepConfidence = 6
