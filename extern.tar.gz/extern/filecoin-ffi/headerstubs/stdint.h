typedef unsigned char uint8_t;
typedef unsigned long long uint64_t;
typedef unsigned long int size_t;
#define bool _Bool
