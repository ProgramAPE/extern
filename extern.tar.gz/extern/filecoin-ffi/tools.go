//+build tools

package ffi

import (
	_ "github.com/xlab/c-for-go"
)
